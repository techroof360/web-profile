
<html>
<head>
	<title>Message</title>
</head>
<body>
<?php
if(isset($_POST['send_message'])){
	echo "True";
}
?>	
</body>
</html>